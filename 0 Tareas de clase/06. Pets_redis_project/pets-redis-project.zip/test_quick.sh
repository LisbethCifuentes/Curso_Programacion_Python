#!/bin/bash

# Script de prueba rápida para el proyecto Pets + Redis
# Colores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}🐾 PETS + REDIS - TEST RÁPIDO${NC}"
echo -e "${BLUE}========================================${NC}\n"

# 1. Verificar que los servicios están corriendo
echo -e "${YELLOW}1. Verificando servicios...${NC}"
docker-compose ps

# 2. Verificar Redis
echo -e "\n${YELLOW}2. Probando Redis...${NC}"
REDIS_PING=$(docker exec pets-redis redis-cli ping 2>&1)
if [ "$REDIS_PING" = "PONG" ]; then
    echo -e "${GREEN}✅ Redis está funcionando correctamente${NC}"
else
    echo -e "${RED}❌ Redis no responde${NC}"
fi

# 3. Verificar cantidad de workers
echo -e "\n${YELLOW}3. Verificando workers...${NC}"
WORKERS=$(docker ps | grep consumer | wc -l)
echo -e "${GREEN}✅ Hay $WORKERS workers activos${NC}"

# 4. Ver tareas pendientes en Redis
echo -e "\n${YELLOW}4. Tareas pendientes en cola de Redis:${NC}"
TASKS=$(docker exec pets-redis redis-cli LLEN pets:tasks)
echo -e "${BLUE}📋 Tareas pendientes: $TASKS${NC}"

# 5. Ver últimos logs de workers
echo -e "\n${YELLOW}5. Últimos logs de workers:${NC}"
echo -e "${BLUE}--- Consumer 1 ---${NC}"
docker logs --tail 3 pets-consumer-1

echo -e "\n${BLUE}--- Consumer 2 ---${NC}"
docker logs --tail 3 pets-consumer-2

echo -e "\n${BLUE}--- Consumer 3 ---${NC}"
docker logs --tail 3 pets-consumer-3

# 6. Verificar archivos procesados
echo -e "\n${YELLOW}6. Archivos procesados generados:${NC}"
PROCESSED_FILES=$(docker exec pets-consumer-1 ls -1 /app/processed_data 2>/dev/null | wc -l)
echo -e "${GREEN}✅ Se han generado $PROCESSED_FILES archivos JSON${NC}"

if [ "$PROCESSED_FILES" -gt 0 ]; then
    echo -e "${BLUE}Últimos archivos:${NC}"
    docker exec pets-consumer-1 ls -lht /app/processed_data | head -n 5
fi

# 7. Verificar API
echo -e "\n${YELLOW}7. Probando API (vista pública)...${NC}"
STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/)
if [ "$STATUS" = "200" ]; then
    echo -e "${GREEN}✅ API respondiendo correctamente (Status: $STATUS)${NC}"
else
    echo -e "${RED}❌ API no responde correctamente (Status: $STATUS)${NC}"
fi

echo -e "\n${BLUE}========================================${NC}"
echo -e "${GREEN}✅ Pruebas completadas${NC}"
echo -e "${BLUE}========================================${NC}\n"

echo -e "${YELLOW}💡 Próximos pasos:${NC}"
echo -e "1. Crear un usuario: ${BLUE}docker exec -it pets-django-api python manage.py createsuperuser${NC}"
echo -e "2. Obtener token: ${BLUE}curl -X POST http://localhost:8000/api/token/ ...${NC}"
echo -e "3. Crear mascotas: ${BLUE}curl -X POST http://localhost:8000/api/pets/ ...${NC}"
echo -e "4. Ver el README.md para más detalles\n"
