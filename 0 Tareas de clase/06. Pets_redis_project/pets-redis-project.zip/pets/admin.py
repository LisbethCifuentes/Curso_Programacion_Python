from django.contrib import admin

# No es necesario registrar modelos de MongoEngine aquí
# porque no usan el admin de Django de la misma manera

# Si quieres ver las mascotas en el admin, necesitarías
# una librería adicional como django-mongoengine
# Por ahora, este archivo puede quedar así o vacío